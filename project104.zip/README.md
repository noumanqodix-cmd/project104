# project104

## A Functional Fitness App

## Current Issues/Bugs:

- in the Workout Schedule page of the get started wizard, the "Days per week" and "Session duration" buttons do not highlight when clicked.
- can't start a workout; app seems to return to home screen and change workout day to rest day 
- cardio exercises should not use reps, and should instead use time duration and effort level (e.g. RPE)
